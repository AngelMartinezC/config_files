import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import pyPLUTO as pypl
import pyPLUTO.pload as pp
import pyPLUTO.Image as img
import pyPLUTO.Tools as tl
import multiprocessing
from joblib import Parallel, delayed
import os
import time
from matplotlib.ticker import StrMethodFormatter


# -- To save in folder
if os.path.exists('IMAGES'): print('Folder exists.')
else: os.system('mkdir IMAGES')

# Normalization units
unit_v = 1e5
unit_rho = 1e-6
unit_b = np.sqrt(4*np.pi*unit_rho*unit_v**2)

wdir = 'dbl_files/'
X0 = float(os.popen("grep 'X1' '"+wdir+"/grid.out' | tr -d '[a-z]' | \
    awk '{print $3}' | sed 's/,//g'").read())
X1 = float(os.popen("grep 'X1' '"+wdir+"/grid.out' | tr -d '[a-z]' | \
    awk '{print $4}' | sed 's/,//g'").read())
Y0 = float(os.popen("grep 'X2' '"+wdir+"/grid.out' | tr -d '[a-z]' | \
    awk '{print $3}' | sed 's/,//g'").read())
Y1 = float(os.popen("grep 'X2' '"+wdir+"/grid.out' | tr -d '[a-z]' | \
    awk '{print $4}' | sed 's/,//g'").read())
resX = 9
resY = 8 #10 #27
XX = np.around(np.linspace(X0,X1,resX)/1e3,2)#.astype(int)
YY = np.around(np.linspace(Y0,Y1,resY)/1e3,2)#.astype(int)
nlinf = pypl.nlast_info(w_dir=wdir)#, datatype='flt')
number = nlinf['nlast']
SSS = []#*number

def image(i=0, cmap='gnuplot', diff=False,unit=1,res=20,resy=15,plot=False,zcut=10):
  D, I = pp.pload(i, w_dir=wdir), img.Image()
  if diff:
    vmin = -0.5
    vmax = 0.5
    D0 = pp.pload(i-1, w_dir=wdir)
    VAR  = D.rho - D0.rho
  else:
    vmin =  np.log10(0.19)  #np.log10(20)   #None  #0 #None #0.2
    vmax =  np.log10(130.0) #40.0  #np.log10(730.0)   #None #13 #None #5.0
    VAR  =  np.log10(D.rho) #D.Bx2*unit_b #np.log10(D.rho)  #D.Bx2*unit_b
  I.pldisplay(D,VAR,x1=D.x1,x2=D.x2,label1='x [Mm]',label2='Depth [Mm]', \
      figsize=[17, 8], vmin=vmin, vmax=vmax, \
      cbarlabel=r'Density ($\times 10^{6}$) [g cm$^{-3}$]', \
      #cbarlabel=r'$B_y$ [Gauss]', \
      cbar=(True,'vertical'),aspect='auto', cmap=cmap)
  T, newdims = tl.Tools(), (resy,res)
  Xmesh, Ymesh = np.meshgrid(D.x1.T,D.x2.T)
  xcong = T.congrid(Xmesh,newdims,method='linear')
  ycong = T.congrid(Ymesh,newdims,method='linear')
  velxcong = T.congrid(D.vx1.T,newdims,method='linear')
  velycong = T.congrid(D.vx2.T,newdims,method='linear')
  plt.gca().quiver(xcong, ycong, velxcong, velycong,ec='w',fc='k',lw=0.8,\
      width=0.0030, headwidth=3, alpha=0.7)
  plt.xticks(np.linspace(D.x1[0],D.x1[-1],resX),XX)
  plt.yticks(np.linspace(D.x2[0],D.x2[-1],resY),YY)
  minute, second = divmod(D.SimTime,60)
  hour, minute   = divmod(minute,60)
  day, hour      = divmod(hour,24)
  plt.title('Time: {} days  {} h  {} min {} s'.format(int(day),int(hour),
      int(minute),round(second,2)), fontsize=20)
  string = '%0.4d' % (i)  # To save CUSTOM FRAME With name pic.000#.png
  plt.grid(ls='-.',color='silver', lw=1, alpha=0.7)#color='slategray')
  plt.tight_layout()
  print("Image %04d"%i)
  plt.savefig('IMAGES/pic.'+string+'.png',dpi=90)
  if plot: plt.show()
  else: plt.close("all")
nlinf = pypl.nlast_info(w_dir=wdir)#, datatype='flt')
number = nlinf['nlast']

#image(0,'gnuplot',diff=False,res=20,resy=35,plot=True)#,unit=354.490770,res=20)
#exit()


s = time.time()
print("Number of files is %d"%number)
num_cores = multiprocessing.cpu_count()
processed_list = Parallel(n_jobs=num_cores)(delayed(image)(i)
    for i in range(12056,number,1))
#    for i in range(1499,number,1))
print("Time spent {:.2f} s".format(time.time()-s))
os.system('notify-send "Terminal" "python image.py"; echo -en "\007"')


# Make an imshow of density as a function of time
#D, I = pp.pload(0, w_dir=wdir), img.Image()
#for j in np.arange(1,31,1):
#  plt.figure(figsize=(10,8))
#  for i in np.arange(0,2106,5):
#    image(i,zcut=4*j)
#  dens = np.array(SSS)[0,0]
#  plt.imshow(np.array(SSS).T,origin='lower',aspect='auto',cmap='jet',\
#      vmin=dens*0.9,vmax=dens*1.10,\
#      extent=[0,6,D.x1.min(),D.x1.max()])
#  SSS *= 0
#  plt.colorbar(label=r"Density [g cm$^{-3}$]")
#  plt.ylabel(r"$x$ [Mm]")
#  plt.xlabel(r"Time [h]")
#  zcut_str = 7.5*4*j
#  str_cut = '%d' % zcut_str
#  plt.title("$z=$"+str(str_cut)+" km")
#  plt.yticks(np.linspace(D.x1[0],D.x1[-1],resX),XX)
#  plt.xticks(np.linspace(0,6,7),np.linspace(0,6,7))
#  plt.tight_layout()
#  frame = '%0.4d' % j
#  plt.savefig("IMAGES_TIME/pic."+frame+".png")
#  plt.close("all")
##plt.show()
#exit()


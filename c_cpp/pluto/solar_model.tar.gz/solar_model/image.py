import numpy as np
import matplotlib.pyplot as plt
import matplotlib as mpl
import pyPLUTO.pload as pp
import pyPLUTO.Image as img
import pyPLUTO.Tools as tl
import multiprocessing
from joblib import Parallel, delayed
import os
import time


# -- To save in folder
if os.path.exists('IMAGES'):
    print('Folder exists.')
else:
  os.system('mkdir IMAGES')


wdir = 'dbl_files/'

X0 = float(os.popen("grep 'X1' 'dbl_files/grid.out' | tr -d '[a-z]' | awk '{print $3}' | sed 's/,//g'").read())
X1 = float(os.popen("grep 'X1' 'dbl_files/grid.out' | tr -d '[a-z]' | awk '{print $4}' | sed 's/,//g'").read())
Y0 = float(os.popen("grep 'X2' 'dbl_files/grid.out' | tr -d '[a-z]' | awk '{print $3}' | sed 's/,//g'").read())
Y1 = float(os.popen("grep 'X2' 'dbl_files/grid.out' | tr -d '[a-z]' | awk '{print $4}' | sed 's/,//g'").read())
XX = (np.linspace(X0,X1,5)/1e3).astype(int)
YY = (np.linspace(Y1,Y0,6)/1e3).astype(int)

def image(i=0, cmap='jet_r', diff=True):
  D = pp.pload(i, w_dir=wdir)
  D0 = pp.pload(i-1, w_dir=wdir)
  I = img.Image()
  if diff:
    vmin = -0.2
    vmax =  0.2
    VAR  = D.rho - D0.rho
  else:
    vmin =  0.0
    vmax =  700
    VAR  = D.rho

  
  I.pldisplay(D,VAR,x1=D.x1,x2=D.x2,label1='x [Mm]',label2='Depth [Mm]', \
      figsize=[10,11], vmin=vmin, vmax=vmax, \
      cbarlabel=r'Density ($\times 10^{6}$) [g cm$^{-3}$]', \
      cbar=(True,'vertical'),aspect='auto', cmap=cmap)
      #vmin=-0.2,vmax=0.2, wdir='dbl_files/',image=True, unit=1,diff=True)
      #vmin=0.0,vmax=700, wdir='dbl_files/',image=True, unit=1,diff=True, \
      #vmin=-0.1,vmax=0.1, wdir='dbl_files/',image=True,unit=1,diff=True)

  T = tl.Tools()
  newdims = 2*(20,)
  Xmesh, Ymesh = np.meshgrid(D.x1.T,D.x2.T)
  xcong = T.congrid(Xmesh,newdims,method='linear')
  ycong = T.congrid(Ymesh,newdims,method='linear')
  velxcong = T.congrid(D.vx1.T,newdims,method='linear')
  velycong = T.congrid(D.vx2.T,newdims,method='linear')
  plt.gca().quiver(xcong, ycong, velxcong, velycong,ec='w',fc='k',lw=0.5,\
      width=0.0035, headwidth=4)

  plt.xticks(np.linspace(D.x1[0],D.x1[-1],5),XX)
  plt.yticks(np.linspace(D.x2[0],D.x2[-1],6),YY)
  minute = i
  days = int(minute // 1440)
  hours = int((minute - (days*1440)) // 60)
  minutes = int((minute - (days*1440) - (hours*60)) // 1)
  plt.title('Time: {} days  {} h  {} min'.format(days,hours,minutes), 
      fontsize=20)
  #mpl.rcParams.update({'font.size': 18})
  #if i<10000:
  string = '%0.4d' % (i)  # To save CUSTOM FRAME With name pic.000#.png
  #else:
  #  string = '%0.5d' % (i)  # To save CUSTOM FRAME With name pic.0000#.png
  plt.tight_layout()
  plt.grid(ls='-.',color='silver', lw=1)#color='slategray')
  print("Image %04d"%i)
  plt.savefig('IMAGES/pic.'+string+'.png')
  plt.close("all")
  #plt.show()

#image(20000,'jet_r',diff=True)
exit()

s = time.time()
number = int(os.popen('ls dbl_files/rho* | grep .dbl | wc -l').read())

print("Number of files is %d"%number)
num_cores = multiprocessing.cpu_count()
processed_list = Parallel(n_jobs=num_cores)(delayed(image)(i)
    for i in range(1,number,10))
print("Time spent {:.2f} s".format(time.time()-s))


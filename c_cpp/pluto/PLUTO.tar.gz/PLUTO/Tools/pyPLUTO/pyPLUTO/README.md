Change line 58 of `Image.py` in order to shrink accordingly the size

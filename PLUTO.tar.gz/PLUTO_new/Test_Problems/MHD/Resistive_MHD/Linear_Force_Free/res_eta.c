#include "pluto.h"

void Resistive_eta(double *v, double x1, double x2, double x3,
                   double *J, double *eta)
{
  eta[0] = 1.0;
  eta[1] = 1.0;
  eta[2] = 1.0;
}
